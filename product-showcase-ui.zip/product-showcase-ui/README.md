# Product Showcase UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/izbranco/pen/ExQrmwK](https://codepen.io/izbranco/pen/ExQrmwK).

Inspired by Francesco Zagami
https://dribbble.com/shots/15292175-Product-Carousel-Experience
